
  DMDE (Disk Editor and Data Recovery Software) 3.0
  The software is to search, edit, and recover data on disks

  Copyright (c) 2005-2016 Dmitry Sidorov

  WWW:    http://dmde.com/
          http://softdm.com/

  The software may be used under the terms of the license 
  agreements in the file "eula_en.txt".
  Be sure to know system requirements before use.